void main()
{
  Test7 t;
  t.example();
}
