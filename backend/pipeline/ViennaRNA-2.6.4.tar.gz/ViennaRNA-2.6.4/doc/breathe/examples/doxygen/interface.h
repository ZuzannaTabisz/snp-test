/* A dummy interface, which is really just a specially treated class in C++ */

class TestInterface
{
};

/*! \interface TestInterface interface.h "inc/interface.h"
 *  \brief This is a test interface.
 *
 * Some details about the TestInterface interface
 */
