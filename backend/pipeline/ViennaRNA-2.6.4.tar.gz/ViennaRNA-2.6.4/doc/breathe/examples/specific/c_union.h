
union ACUnion {
	int i;
};

