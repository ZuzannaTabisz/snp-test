

namespace test {

typedef float MyFloat;

void TestFunc() {};

}

class TestClass {
public:
    /// enum docs
    enum Enum {};
};
