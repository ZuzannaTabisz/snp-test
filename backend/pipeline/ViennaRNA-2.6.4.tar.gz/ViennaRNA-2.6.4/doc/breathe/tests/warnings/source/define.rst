
Define Warnings
===============

Test 'cannot find project' warning.

.. doxygendefine:: MY_DEFINE
   :project: nonexistent

Test 'cannot find define' warning.

.. doxygendefine:: MY_DEFINE
   :project: class

