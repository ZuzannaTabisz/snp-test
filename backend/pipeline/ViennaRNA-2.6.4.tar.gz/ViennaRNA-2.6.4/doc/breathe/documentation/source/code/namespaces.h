
/*! A namespace for nothing. */
namespace test_namespace {

/*! A very important class. */
class Sample1
{
public:
    Sample1() {}
};

/*! Even more important class */
class Sample2
{
    Sample2() {}
};

/*! A function in the namespace */
void foo() {}

}
