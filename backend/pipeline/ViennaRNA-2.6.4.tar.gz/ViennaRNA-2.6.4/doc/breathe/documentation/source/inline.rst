
Inline Parameter Documentation
==============================

This is currently flawed as it doesn't know where to sensibly put the parameters
in the final description.

It currently defaults to the top of the detail description block which means it
comes between the brief description text and the detailed description text which
is less than ideal, but attempts to programmatically figure out where the detail
description text ends have failed. Something for future work.

Example
-------

.. cpp:namespace:: @ex_inline

.. doxygenindex:: 
   :path: ../../examples/specific/inline/xml


