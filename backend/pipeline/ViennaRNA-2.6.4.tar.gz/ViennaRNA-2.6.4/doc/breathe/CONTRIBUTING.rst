
Contributing
============

Firstly, thank you for making it this far. We really appreciate anyone who even
thinks about reporting an issue or helping out with the code or docs. It is kind
of you to take the time.

Please Provide an Example
-------------------------

If you're having trouble with how the contents of a particular Doxygen comment
or a particular set of code is being processed then please provide an example of
the in question.

Ideally as a pull-request with additions to the `examples/specific` folder but
feel free to provide the comment content in your issue instead.

It really helps to accelerate development if we have examples to work from.
